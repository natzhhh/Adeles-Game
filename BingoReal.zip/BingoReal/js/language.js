///language changing material
var  sing = document.getElementById('35Balls');
var  mul = document.getElementById('housePlay');
var   ball45 = document.getElementById('45Balls');
var  help = document.getElementById('helpLan');
var  SectionName = document.getElementById('SectionName');
var languageSelect = document.getElementById('language-select');
var lang = document.getElementById('lang');
var again = document.getElementById('again');
var home = document.getElementById('home');
var fast  = document.getElementById('fast');
var slow  = document.getElementById('slow');
var on = document.getElementById('on');
var off  = document.getElementById('off');


  languageSelect.addEventListener('change', function() {
   if(languageSelect.value === 'fr') {
    sing.innerHTML = '35 ኳሶች';
    mul.innerHTML = 'ከቤቱ ካርድ ጋር ይጫወቱ';
    ball45.innerHTML ='45 ኳሶች'
    help.innerHTML ='እርዳታ/ማብራሪያ';
    SectionName.innerHTML = '35 ኳሶች፡ የቢንጎ ጨዋታ አይነት ሲሆን 35 ኳሶች በየተራ ይወጣሉ፡ ኳሶችሁ ወተው ከማለቃቸው በፊት ወደ ጎን ወይም ወደ ታች ወይም አግድም የዘጋ ቢንጎ ካለ አሸናፊ ይሆናል። .........    ከቤቱ ጋር ጨዋታ፡ ደሞ ቢንጎ ጨዋታው ከቤቱ ካርድ ጋር ነው የሚለየው ነገር የዝጉን አይነት ኮምፑውተሩ የሚመርጥ ሲሆን ዝጉን ቀድሞ የዘጋ አሸናፊ ይሆናል።  .....    45 ኳሶች፡ አጨዋወቱ እንደ 35 ኳሶች ሲሆን የሚለየው 45 ጊዜ ኳሶቹ መውጣታቸው ነው ። '
     again.innerHTML ='እንደገና ይጫወቱ';
     home.innerHTML ='ወደማውጫው ይመለሱ';
     fast.innerHTML ='ፈጣን';
     slow.innerHTML ="ዝግ ያለ";
     on.innerHTML ='ያለው';
     off.innerHTML ="ይጥፋ";
   
   
     } else {
      sing.innerHTML = '35 Balls';
      mul.innerHTML = 'Play With House ';
    SectionName.innerHTML = "35 Balls:  is a Bingo game in which 35 balls will bounce, if you close  row, coulmn or diagonal of your card you click Bingo button and that means you win! It will continue untill the last ball. ....45 Balls:  is a Bingo game in which 45 balls will bounce, if you close  row, coulmn or diagonal of your card you click Bingo button and that means you win! It will continue untill the last ball if you win again click Bingo button again you will add a coin into your coin Bank!   .... Play with House: is a Bingo game in which you play with the house card there is a playing pattern which ever card finish the playing pattern first it will going to be the winner!";
    again.innerHTML ='Play Again';
    home.innerHTML ='Home';
    fast.innerHTML ='fast';
    slow.innerHTML ='slow';
    on.innerHTML ='on';
     off.innerHTML ="off";
   
  }
});